//
//  Game.cpp
//  SFMLproject
//
//  Created by Yasmina Halbouny on 4/28/20.
//  Copyright © 2020 Yasmina Halbouny. All rights reserved.
//

#include "Game.hpp"
